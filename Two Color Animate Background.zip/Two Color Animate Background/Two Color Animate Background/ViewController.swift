//
//  ViewController.swift
//  Two Color Animate Background
//
//  Created by Abhishek Verma on 26/08/17.
//  Copyright © 2017 Abhishek Verma. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.TwoColorAnimateBackground()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func TwoColorAnimateBackground() {
        UIView.animate(withDuration: 1, animations: {
            self.view.backgroundColor = UIColor.init(red: 1/255, green: 122/255, blue: 255/255, alpha: 1.0)
        }, completion: {
            (completed : Bool) -> Void in
            UIView.animate(withDuration: 1, delay: 0, options: .curveLinear, animations: {
                self.view.backgroundColor = UIColor.init(red: 255/255, green: 0/255, blue: 128/255, alpha: 1.0)
            }, completion: {
                (completed : Bool) -> Void in
               self.TwoColorAnimateBackground()
            })
        })
    }
    override var preferredStatusBarStyle: UIStatusBarStyle
        {
        return .lightContent
    }


}

